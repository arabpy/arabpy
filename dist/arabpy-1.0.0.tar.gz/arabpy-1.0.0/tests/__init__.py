"""
Tests for ArabPy package.
"""
